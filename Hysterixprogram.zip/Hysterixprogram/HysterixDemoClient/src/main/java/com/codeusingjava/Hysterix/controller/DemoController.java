package com.codeusingjava.Hysterix.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/client")
public class DemoController {

    @Autowired
    public RestTemplate restTemplate;

    @GetMapping
    @HystrixCommand(fallbackMethod = "handleFallback")
    public String test(){
        String url = "http://HysterixDemoServer/api/server";
        return restTemplate.getForObject(url, String.class);
    }

    public String handleFallback(){
        return "This service is fallback service. It is called when HysterixDemoServer is down";
    }
}
