package com.codeusingjava.Hysterix.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/server")
public class HelloController {

    @GetMapping
    public String message(){
        return "Welcome to Hysterix Demo Server";
    }

}
