package com.spring.cloud.gateway.Controller1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "ecommerce")	
public class OrderController {

	/**
	 * Sample Get Request Method
	 * @return
	 */
	@RequestMapping(value = "/order/user", method = RequestMethod.GET)
	public String userLoginValidation() {
		return "You Order Details is successfully validated. Welcome to the Application.. ";
	}
}
